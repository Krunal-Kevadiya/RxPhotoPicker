package uk.co.b60apps.novabods.data.adapter;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Response;
import retrofit2.Retrofit;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.exceptions.CompositeException;
import rx.exceptions.Exceptions;
import rx.exceptions.OnCompletedFailedException;
import rx.exceptions.OnErrorFailedException;
import rx.exceptions.OnErrorNotImplementedException;
import rx.plugins.RxJavaPlugins;
import uk.co.b60apps.novabods.data.models.common.ResultBean;

final class BodyOnSubscribe<T> implements OnSubscribe<T> {
    private static Type responseType;
    private static Retrofit retrofit;
    private final OnSubscribe<Response<T>> upstream;

    BodyOnSubscribe(Retrofit retrofit, Type responseType, OnSubscribe<Response<T>> upstream) {
        BodyOnSubscribe.responseType = responseType;
        BodyOnSubscribe.retrofit = retrofit;
        this.upstream = upstream;
    }

    @Override
    public void call(Subscriber<? super T> subscriber) {
        upstream.call(new BodySubscriber<T>(subscriber));
    }

    private static class BodySubscriber<R> extends Subscriber<Response<R>> {
        private final Subscriber<? super R> subscriber;
        private boolean subscriberTerminated;

        BodySubscriber(Subscriber<? super R> subscriber) {
            super(subscriber);
            this.subscriber = subscriber;
        }

        @Override
        public void onNext(Response<R> response) {
            if(response.isSuccessful()) {
                R r = response.body();
                if (r != null) {
                    ((ResultBean) r).setHttpCode(response.code());
                    ((ResultBean) r).setHttpMessage(response.message());
                }
                subscriber.onNext(r);
            } else {
                Converter<ResponseBody, R> converter = retrofit.responseBodyConverter(responseType, new Annotation[0]);
                try {
                    R r = converter.convert(response.errorBody());
                    if (r != null) {
                        ((ResultBean) r).setHttpCode(response.code());
                        ((ResultBean) r).setHttpMessage(response.message());
                    }
                    subscriber.onNext(r);
                } catch (IOException e) {
                    subscriberTerminated = true;
                    Throwable t = new HttpException(response);
                    try {
                        subscriber.onError(t);
                    } catch (OnCompletedFailedException
                            | OnErrorFailedException
                            | OnErrorNotImplementedException e1) {
                        RxJavaPlugins.getInstance().getErrorHandler().handleError(e1);
                    } catch (Throwable inner) {
                        Exceptions.throwIfFatal(inner);
                        CompositeException composite = new CompositeException(t, inner);
                        RxJavaPlugins.getInstance().getErrorHandler().handleError(composite);
                    }
                }
            }
        }

        @Override
        public void onError(Throwable throwable) {
            if (!subscriberTerminated) {
                subscriber.onError(throwable);
            } else {
                Throwable broken = new AssertionError("This should never happen! Report as a Retrofit bug with the full stacktrace.");
                broken.initCause(throwable);
                RxJavaPlugins.getInstance().getErrorHandler().handleError(broken);
            }
        }

        @Override
        public void onCompleted() {
            if (!subscriberTerminated) {
                subscriber.onCompleted();
            }
        }
    }
}
