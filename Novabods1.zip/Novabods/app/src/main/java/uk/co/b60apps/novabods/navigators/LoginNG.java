package uk.co.b60apps.novabods.navigators;

import com.kevadiyakrunalk.mvvmarchitecture.common.Navigator;

public class LoginNG implements Navigator {
}
