package uk.co.b60apps.novabods.data.models.common;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ResultBean<SuccessModel, ErrorModel> {
    //HTTP CODE
    private int httpCode;
    private String httpMessage;

    public int getHttpCode() {
        return httpCode;
    }

    public void setHttpCode(int httpCode) {
        this.httpCode = httpCode;
    }

    public String getHttpMessage() {
        return httpMessage;
    }

    public void setHttpMessage(String httpMessage) {
        this.httpMessage = httpMessage;
    }

    //API SUCCESS
    @SerializedName("accessToken")
    @Expose
    private String accessToken;
    @SerializedName("accessTokenExpiration")
    @Expose
    private String accessTokenExpiration;
    @SerializedName("user")
    @Expose
    private SuccessModel successModel;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getAccessTokenExpiration() {
        return accessTokenExpiration;
    }

    public void setAccessTokenExpiration(String accessTokenExpiration) {
        this.accessTokenExpiration = accessTokenExpiration;
    }

    public SuccessModel getSuccessModel() {
        return successModel;
    }

    public void setSuccessModel(SuccessModel successModel) {
        this.successModel = successModel;
    }

    //API ERROR
    @SerializedName("error_code")
    @Expose
    private int errorCode;
    @SerializedName("error")
    @Expose
    private Error<ErrorModel> error;

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public Error<ErrorModel> getError() {
        return error;
    }

    public void setError(Error<ErrorModel> error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "ResultBean{" +
                "httpCode=" + httpCode +
                ", httpMessage='" + httpMessage + '\'' +
                ", accessToken='" + accessToken + '\'' +
                ", accessTokenExpiration='" + accessTokenExpiration + '\'' +
                ", successModel=" + successModel +
                ", errorCode=" + errorCode +
                ", error=" + error +
                '}';
    }
}
