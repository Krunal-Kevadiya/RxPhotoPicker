package uk.co.b60apps.novabods;

import android.app.Application;

public class MyNovabods extends Application {
}
