package uk.co.b60apps.novabods.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*{
    "country_id": 1,
    "name": "Afghanistan",
    "iso2": "AF",
    "iso3": "AFG",
    "iso3_number": 4,
    "provinces": null
}*/

/**
 * The type Country bean.
 */
public class CountryBean {
    @SerializedName("country_id")
    @Expose
    private int countryId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("iso2")
    @Expose
    private String iso2;
    @SerializedName("iso3")
    @Expose
    private String iso3;
    @SerializedName("iso3_number")
    @Expose
    private int iso3Number;
    @SerializedName("provinces")
    @Expose
    private Object provinces;

    /**
     * Gets country id.
     *
     * @return - country id as integer
     */
    public int getCountryId() {
        return countryId;
    }

    /**
     * Sets country id.
     *
     * @param countryId - country id as integer
     */
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    /**
     * Gets country name.
     *
     * @return - name as String
     */
    public String getName() {
        return name;
    }

    /**
     * Sets country name.
     *
     * @param name - name as String
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets iso 2.
     *
     * @return - iso 2 as String
     */
    public String getIso2() {
        return iso2;
    }

    /**
     * Sets iso 2.
     *
     * @param iso2 - iso 2 as String
     */
    public void setIso2(String iso2) {
        this.iso2 = iso2;
    }

    /**
     * Gets iso 3.
     *
     * @return - iso 3 as String
     */
    public String getIso3() {
        return iso3;
    }

    /**
     * Sets iso 3.
     *
     * @param iso3 - iso 3 as String
     */
    public void setIso3(String iso3) {
        this.iso3 = iso3;
    }

    /**
     * Gets iso 3 number.
     *
     * @return - iso 3 number as integer
     */
    public int getIso3Number() {
        return iso3Number;
    }

    /**
     * Sets iso 3 number.
     *
     * @param iso3Number - iso 3 number as integer
     */
    public void setIso3Number(int iso3Number) {
        this.iso3Number = iso3Number;
    }

    /**
     * Gets provinces.
     *
     * @return - provinces as Object
     */
    public Object getProvinces() {
        return provinces;
    }

    /**
     * Sets provinces.
     *
     * @param provinces - provinces as Object
     */
    public void setProvinces(Object provinces) {
        this.provinces = provinces;
    }

    @Override
    public String toString() {
        return "CountryBean{" +
                "countryId=" + countryId +
                ", name='" + name + '\'' +
                ", iso2='" + iso2 + '\'' +
                ", iso3='" + iso3 + '\'' +
                ", iso3Number=" + iso3Number +
                ", provinces=" + provinces +
                '}';
    }
}