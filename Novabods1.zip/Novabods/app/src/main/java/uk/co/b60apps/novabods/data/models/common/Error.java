package uk.co.b60apps.novabods.data.models.common;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Error<ErrorDerail> {
    @SerializedName("error_code")
    @Expose
    private int errorCode;
    @SerializedName("error_exception")
    @Expose
    private String errorException;
    @SerializedName("error_description")
    @Expose
    private String errorDescription;
    @SerializedName("error_details")
    @Expose
    private ErrorDerail errorDetails;

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorException() {
        return errorException;
    }

    public void setErrorException(String errorException) {
        this.errorException = errorException;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public ErrorDerail getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(ErrorDerail errorDetails) {
        this.errorDetails = errorDetails;
    }

    @Override
    public String toString() {
        return "Error{" +
                "errorCode=" + errorCode +
                ", errorException='" + errorException + '\'' +
                ", errorDescription='" + errorDescription + '\'' +
                ", errorDetails=" + errorDetails +
                '}';
    }
}