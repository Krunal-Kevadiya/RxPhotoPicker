package uk.co.b60apps.novabods.viewmodels;

import com.kevadiyakrunalk.mvvmarchitecture.common.BaseViewModel;

public class SplashVM extends BaseViewModel {
}
