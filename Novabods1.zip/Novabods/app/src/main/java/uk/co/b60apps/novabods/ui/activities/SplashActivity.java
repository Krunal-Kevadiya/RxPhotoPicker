package uk.co.b60apps.novabods.ui.activities;

import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;

import com.kevadiyakrunalk.mvvmarchitecture.common.BindingConfig;

import uk.co.b60apps.novabods.R;
import uk.co.b60apps.novabods.base.BaseActivity;
import uk.co.b60apps.novabods.databinding.SplashBR;
import uk.co.b60apps.novabods.viewmodels.SplashVM;

public class SplashActivity extends BaseActivity<SplashBR, SplashVM> {

    @NonNull
    @Override
    public BindingConfig getBindingConfig() {
        return new BindingConfig(R.layout.activity_splash);
    }

    @NonNull
    @Override
    public SplashVM createViewModel() {
        return new SplashVM();
    }

    @Override
    protected void onResume() {
        super.onResume();
        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            finish();
        }, 2000);
    }
}
