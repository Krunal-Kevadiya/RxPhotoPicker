package uk.co.b60apps.novabods.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*{
    "productSku": "SKU-00000008",
    "productName": "Family",
    "productDescription": "This is the product for a family subscription.",
    "is_active": true,
    "ratePlanId": "2c92c0f95388d4af01539a4c739e0a8a",
    "ratePlanName": "12 Months",
    "ratePlanDescription": "recurring every 12 Months",
    "ratePlanOrder": 12,
    "ratePlanActive": "Yes",
    "ratePlanOneTimeCharge": null,
    "ratePlanDefaultDuration": "12",
    "ratePlanDefaultDurationType": "Month",
    "ratePlanEffectiveStartDate": "2016-03-21",
    "ratePlanEffectiveEndDate": "2099-03-21",
    "ratePlanChargeName": "Family 12 Month Subscription",
    "ratePlanChargeTaxCode": "EU VAT",
    "ratePlanChargeDescription": "",
    "ratePlanChargePriceCurrency": "GBP",
    "ratePlanChargePriceCurrencySymbol": "£",
    "ratePlanChargePricePrice": 35.82,
    "ratePlanChargePriceMonthlyRate": 2.99
}*/

/**
 * The type Product bean.
 */
public class ProductBean {
    @SerializedName("productSku")
    @Expose
    private String productSku;
    @SerializedName("productName")
    @Expose
    private String productName;
    @SerializedName("productDescription")
    @Expose
    private String productDescription;
    @SerializedName("is_active")
    @Expose
    private boolean isActive;
    @SerializedName("ratePlanId")
    @Expose
    private String ratePlanId;
    @SerializedName("ratePlanName")
    @Expose
    private String ratePlanName;
    @SerializedName("ratePlanDescription")
    @Expose
    private String ratePlanDescription;
    @SerializedName("ratePlanOrder")
    @Expose
    private int ratePlanOrder;
    @SerializedName("ratePlanActive")
    @Expose
    private String ratePlanActive;
    @SerializedName("ratePlanOneTimeCharge")
    @Expose
    private Object ratePlanOneTimeCharge;
    @SerializedName("ratePlanDefaultDuration")
    @Expose
    private String ratePlanDefaultDuration;
    @SerializedName("ratePlanDefaultDurationType")
    @Expose
    private String ratePlanDefaultDurationType;
    @SerializedName("ratePlanEffectiveStartDate")
    @Expose
    private String ratePlanEffectiveStartDate;
    @SerializedName("ratePlanEffectiveEndDate")
    @Expose
    private String ratePlanEffectiveEndDate;
    @SerializedName("ratePlanChargeName")
    @Expose
    private String ratePlanChargeName;
    @SerializedName("ratePlanChargeTaxCode")
    @Expose
    private String ratePlanChargeTaxCode;
    @SerializedName("ratePlanChargeDescription")
    @Expose
    private String ratePlanChargeDescription;
    @SerializedName("ratePlanChargePriceCurrency")
    @Expose
    private String ratePlanChargePriceCurrency;
    @SerializedName("ratePlanChargePriceCurrencySymbol")
    @Expose
    private String ratePlanChargePriceCurrencySymbol;
    @SerializedName("ratePlanChargePricePrice")
    @Expose
    private float ratePlanChargePricePrice;
    @SerializedName("ratePlanChargePriceMonthlyRate")
    @Expose
    private float ratePlanChargePriceMonthlyRate;

    /**
     * Gets product sku.
     *
     * @return - product sku as String
     */
    public String getProductSku() {
        return productSku;
    }

    /**
     * Sets product sku.
     *
     * @param productSku - product sku as String
     */
    public void setProductSku(String productSku) {
        this.productSku = productSku;
    }

    /**
     * Gets product name.
     *
     * @return - product name as String
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets product name.
     *
     * @param productName - product name as String
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Gets product description.
     *
     * @return - product description as String
     */
    public String getProductDescription() {
        return productDescription;
    }

    /**
     * Sets product description.
     *
     * @param productDescription - product description as String
     */
    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    /**
     * Is active boolean.
     *
     * @return - status as boolean
     */
    public boolean isIsActive() {
        return isActive;
    }

    /**
     * Sets is active.
     *
     * @param isActive - is active as boolean
     */
    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    /**
     * Gets rate plan id.
     *
     * @return - rate plan id as String
     */
    public String getRatePlanId() {
        return ratePlanId;
    }

    /**
     * Sets rate plan id.
     *
     * @param ratePlanId - rate plan id as String
     */
    public void setRatePlanId(String ratePlanId) {
        this.ratePlanId = ratePlanId;
    }

    /**
     * Gets rate plan name.
     *
     * @return - rate plan name as String
     */
    public String getRatePlanName() {
        return ratePlanName;
    }

    /**
     * Sets rate plan name.
     *
     * @param ratePlanName - rate plan name as String
     */
    public void setRatePlanName(String ratePlanName) {
        this.ratePlanName = ratePlanName;
    }

    /**
     * Gets rate plan description.
     *
     * @return - rate plan description as String
     */
    public String getRatePlanDescription() {
        return ratePlanDescription;
    }

    /**
     * Sets rate plan description.
     *
     * @param ratePlanDescription - rate plan description as String
     */
    public void setRatePlanDescription(String ratePlanDescription) {
        this.ratePlanDescription = ratePlanDescription;
    }

    /**
     * Gets rate plan order.
     *
     * @return - rate plan order as integer
     */
    public int getRatePlanOrder() {
        return ratePlanOrder;
    }

    /**
     * Sets rate plan order.
     *
     * @param ratePlanOrder - rate plan order as integer
     */
    public void setRatePlanOrder(int ratePlanOrder) {
        this.ratePlanOrder = ratePlanOrder;
    }

    /**
     * Gets rate plan active.
     *
     * @return - rate plan active as String
     */
    public String getRatePlanActive() {
        return ratePlanActive;
    }

    /**
     * Sets rate plan active.
     *
     * @param ratePlanActive - rate plan active as String
     */
    public void setRatePlanActive(String ratePlanActive) {
        this.ratePlanActive = ratePlanActive;
    }

    /**
     * Gets rate plan one time charge.
     *
     * @return - rate plan one time charge as Object
     */
    public Object getRatePlanOneTimeCharge() {
        return ratePlanOneTimeCharge;
    }

    /**
     * Sets rate plan one time charge.
     *
     * @param ratePlanOneTimeCharge - rate plan one time charge as Object
     */
    public void setRatePlanOneTimeCharge(Object ratePlanOneTimeCharge) {
        this.ratePlanOneTimeCharge = ratePlanOneTimeCharge;
    }

    /**
     * Gets rate plan default duration.
     *
     * @return - rate plan default duration as String
     */
    public String getRatePlanDefaultDuration() {
        return ratePlanDefaultDuration;
    }

    /**
     * Sets rate plan default duration.
     *
     * @param ratePlanDefaultDuration - rate plan default duration as String
     */
    public void setRatePlanDefaultDuration(String ratePlanDefaultDuration) {
        this.ratePlanDefaultDuration = ratePlanDefaultDuration;
    }

    /**
     * Gets rate plan default duration type.
     *
     * @return - rate plan default duration type as String
     */
    public String getRatePlanDefaultDurationType() {
        return ratePlanDefaultDurationType;
    }

    /**
     * Sets rate plan default duration type.
     *
     * @param ratePlanDefaultDurationType - rate plan default duration type as String
     */
    public void setRatePlanDefaultDurationType(String ratePlanDefaultDurationType) {
        this.ratePlanDefaultDurationType = ratePlanDefaultDurationType;
    }

    /**
     * Gets rate plan effective start date.
     *
     * @return - rate plan effective start date as String
     */
    public String getRatePlanEffectiveStartDate() {
        return ratePlanEffectiveStartDate;
    }

    /**
     * Sets rate plan effective start date.
     *
     * @param ratePlanEffectiveStartDate - rate plan effective start date as String
     */
    public void setRatePlanEffectiveStartDate(String ratePlanEffectiveStartDate) {
        this.ratePlanEffectiveStartDate = ratePlanEffectiveStartDate;
    }

    /**
     * Gets rate plan effective end date.
     *
     * @return - rate plan effective end date as String
     */
    public String getRatePlanEffectiveEndDate() {
        return ratePlanEffectiveEndDate;
    }

    /**
     * Sets rate plan effective end date.
     *
     * @param ratePlanEffectiveEndDate - rate plan effective end date as String
     */
    public void setRatePlanEffectiveEndDate(String ratePlanEffectiveEndDate) {
        this.ratePlanEffectiveEndDate = ratePlanEffectiveEndDate;
    }

    /**
     * Gets rate plan charge name.
     *
     * @return - rate plan charge name as String
     */
    public String getRatePlanChargeName() {
        return ratePlanChargeName;
    }

    /**
     * Sets rate plan charge name.
     *
     * @param ratePlanChargeName - rate plan charge name as String
     */
    public void setRatePlanChargeName(String ratePlanChargeName) {
        this.ratePlanChargeName = ratePlanChargeName;
    }

    /**
     * Gets rate plan charge tax code.
     *
     * @return - rate plan charge tax code as String
     */
    public String getRatePlanChargeTaxCode() {
        return ratePlanChargeTaxCode;
    }

    /**
     * Sets rate plan charge tax code.
     *
     * @param ratePlanChargeTaxCode - rate plan charge tax code as String
     */
    public void setRatePlanChargeTaxCode(String ratePlanChargeTaxCode) {
        this.ratePlanChargeTaxCode = ratePlanChargeTaxCode;
    }

    /**
     * Gets rate plan charge description.
     *
     * @return - rate plan charge description as String
     */
    public String getRatePlanChargeDescription() {
        return ratePlanChargeDescription;
    }

    /**
     * Sets rate plan charge description.
     *
     * @param ratePlanChargeDescription - rate plan charge description as String
     */
    public void setRatePlanChargeDescription(String ratePlanChargeDescription) {
        this.ratePlanChargeDescription = ratePlanChargeDescription;
    }

    /**
     * Gets rate plan charge price currency.
     *
     * @return - rate plan charge price currency as String
     */
    public String getRatePlanChargePriceCurrency() {
        return ratePlanChargePriceCurrency;
    }

    /**
     * Sets rate plan charge price currency.
     *
     * @param ratePlanChargePriceCurrency - rate plan charge price currency as String
     */
    public void setRatePlanChargePriceCurrency(String ratePlanChargePriceCurrency) {
        this.ratePlanChargePriceCurrency = ratePlanChargePriceCurrency;
    }

    /**
     * Gets rate plan charge price currency symbol.
     *
     * @return - rate plan charge price currency symbol as String
     */
    public String getRatePlanChargePriceCurrencySymbol() {
        return ratePlanChargePriceCurrencySymbol;
    }

    /**
     * Sets rate plan charge price currency symbol.
     *
     * @param ratePlanChargePriceCurrencySymbol - rate plan charge price currency symbol as String
     */
    public void setRatePlanChargePriceCurrencySymbol(String ratePlanChargePriceCurrencySymbol) {
        this.ratePlanChargePriceCurrencySymbol = ratePlanChargePriceCurrencySymbol;
    }

    /**
     * Gets rate plan charge price.
     *
     * @return - rate plan charge price as float
     */
    public float getRatePlanChargePricePrice() {
        return ratePlanChargePricePrice;
    }

    /**
     * Sets rate plan charge price.
     *
     * @param ratePlanChargePricePrice - rate plan charge price as float
     */
    public void setRatePlanChargePricePrice(float ratePlanChargePricePrice) {
        this.ratePlanChargePricePrice = ratePlanChargePricePrice;
    }

    /**
     * Gets rate plan charge price monthly rate.
     *
     * @return - rate plan charge price monthly rate as float
     */
    public float getRatePlanChargePriceMonthlyRate() {
        return ratePlanChargePriceMonthlyRate;
    }

    /**
     * Sets rate plan charge price monthly rate.
     *
     * @param ratePlanChargePriceMonthlyRate - rate plan charge price monthly rate as float
     */
    public void setRatePlanChargePriceMonthlyRate(float ratePlanChargePriceMonthlyRate) {
        this.ratePlanChargePriceMonthlyRate = ratePlanChargePriceMonthlyRate;
    }

    @Override
    public String toString() {
        return "ProductBean{" +
                "productSku='" + productSku + '\'' +
                ", productName='" + productName + '\'' +
                ", productDescription='" + productDescription + '\'' +
                ", isActive=" + isActive +
                ", ratePlanId='" + ratePlanId + '\'' +
                ", ratePlanName='" + ratePlanName + '\'' +
                ", ratePlanDescription='" + ratePlanDescription + '\'' +
                ", ratePlanOrder=" + ratePlanOrder +
                ", ratePlanActive='" + ratePlanActive + '\'' +
                ", ratePlanOneTimeCharge=" + ratePlanOneTimeCharge +
                ", ratePlanDefaultDuration='" + ratePlanDefaultDuration + '\'' +
                ", ratePlanDefaultDurationType='" + ratePlanDefaultDurationType + '\'' +
                ", ratePlanEffectiveStartDate='" + ratePlanEffectiveStartDate + '\'' +
                ", ratePlanEffectiveEndDate='" + ratePlanEffectiveEndDate + '\'' +
                ", ratePlanChargeName='" + ratePlanChargeName + '\'' +
                ", ratePlanChargeTaxCode='" + ratePlanChargeTaxCode + '\'' +
                ", ratePlanChargeDescription='" + ratePlanChargeDescription + '\'' +
                ", ratePlanChargePriceCurrency='" + ratePlanChargePriceCurrency + '\'' +
                ", ratePlanChargePriceCurrencySymbol='" + ratePlanChargePriceCurrencySymbol + '\'' +
                ", ratePlanChargePricePrice=" + ratePlanChargePricePrice +
                ", ratePlanChargePriceMonthlyRate=" + ratePlanChargePriceMonthlyRate +
                '}';
    }
}
