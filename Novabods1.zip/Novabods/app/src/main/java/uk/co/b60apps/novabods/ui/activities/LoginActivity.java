package uk.co.b60apps.novabods.ui.activities;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.kevadiyakrunalk.mvvmarchitecture.common.BindingConfig;

import java.util.HashMap;

import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import uk.co.b60apps.novabods.BuildConfig;
import uk.co.b60apps.novabods.R;
import uk.co.b60apps.novabods.base.BaseNavigationActivity;
import uk.co.b60apps.novabods.data.ApiInterface;
import uk.co.b60apps.novabods.data.ApiModule;
import uk.co.b60apps.novabods.data.Header;
import uk.co.b60apps.novabods.databinding.LoginBR;
import uk.co.b60apps.novabods.navigators.LoginNG;
import uk.co.b60apps.novabods.viewmodels.LoginVM;

public class LoginActivity extends BaseNavigationActivity<LoginNG, LoginBR, LoginVM> {
    @NonNull
    @Override
    public BindingConfig getBindingConfig() {
        return new BindingConfig(R.layout.activity_login);
    }

    @NonNull
    @Override
    public LoginVM createViewModel() {
        return new LoginVM();
    }

    @NonNull
    @Override
    public LoginNG getNavigator() {
        return new LoginNG();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        getBinding().webView.loadUrl("https://www.novabods.com/");

        HashMap<String, String> hashMap = new HashMap<>();
        //hashMap.put("username", "b60.uat.uk@novabods.com");
        //hashMap.put("password", "Pa55word");

        ApiInterface apiModule = new ApiModule().getRetrofitForGsonApi(BuildConfig.BASE_URL, Header.Default.get(this));
        apiModule.login(hashMap).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(userBeanResultBean -> Log.e("KRUNAL", userBeanResultBean.toString()), Throwable::printStackTrace);

    }
}
