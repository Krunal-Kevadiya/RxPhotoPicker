package uk.co.b60apps.novabods.data;

import android.content.Context;
import java.util.HashMap;
import uk.co.b60apps.novabods.R;
import uk.co.b60apps.novabods.utils.Preferences;

/**
 * The enum Header.
 */
public enum Header {
    /**
     * Default header.
     */
    Default(0),
    /**
     * Token header.
     */
    Token(1),
    /**
     * Default with token header.
     */
    DefaultWithToken(2);

    private int type;

    Header(int type) {
        this.type = type;
    }

    /**
     * Get hash map for api header used.
     *
     * @param context - context as application context or activity context
     * @return - hash map base on header type
     */
    public HashMap<String, String> get(Context context) {
        HashMap<String, String> hashMap = new HashMap<>();

        switch (type) {
            case 0:
                hashMap.put(context.getString(R.string.param_content_type), context.getString(R.string.application_json));
                break;
            case 1:
                hashMap.put(context.getString(R.string.param_x_access_token), Preferences.getToken(context));
                break;
            case 2:
                hashMap.put(context.getString(R.string.param_content_type), context.getString(R.string.application_json));
                hashMap.put(context.getString(R.string.param_x_access_token), Preferences.getToken(context));
                break;
        }

        return hashMap;
    }
}