package uk.co.b60apps.novabods.base;

import android.databinding.ViewDataBinding;
import android.os.Bundle;

import com.kevadiyakrunalk.mvvmarchitecture.NavigatingMvvmActivity;
import com.kevadiyakrunalk.mvvmarchitecture.common.NavigatingViewModel;
import com.kevadiyakrunalk.mvvmarchitecture.common.Navigator;

import uk.co.b60apps.novabods.R;

/**
 * The type Base activity.
 *
 * @param <T> - t as Navigator for transaction between two activity/fragment or visa versa(Activity to Fragment, Fragment to Activity)
 * @param <S> - s as ViewDataBinding for data binding object and auto created by android
 * @param <U> - u as MvvmViewModel for presentation model to communicate XML and pojo class
 */
public abstract class BaseNavigationActivity<T extends Navigator, S extends ViewDataBinding, U extends NavigatingViewModel<T>> extends NavigatingMvvmActivity<T, S, U> {
    private int onStartCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        onStartCount = 1;
        if (savedInstanceState == null)
            overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
        else
            onStartCount = 2;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (onStartCount > 1)
            overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
        else if (onStartCount == 1)
            onStartCount++;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Runtime.getRuntime().gc();
    }
}
