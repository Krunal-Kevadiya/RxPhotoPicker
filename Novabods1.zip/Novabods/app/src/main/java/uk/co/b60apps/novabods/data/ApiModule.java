package uk.co.b60apps.novabods.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import uk.co.b60apps.novabods.data.adapter.RxJavaCallAdapterFactory;
import uk.co.b60apps.novabods.utils.Utils;

/**
 * The type Api module.
 */
public class ApiModule {
    /**
     *  get retrofit object for api call
     *
     * @param baseUrl - base url as String for api server address
     * @param header  - header as hash map<String,String> for content type or token pass
     * @return - init retrofit object
     */
    private Retrofit GetRetrofitForGsonApi(final String baseUrl, final HashMap<String, String> header) {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.readTimeout(1, TimeUnit.MINUTES);
        httpClient.connectTimeout(1, TimeUnit.MINUTES);
        httpClient.writeTimeout(1, TimeUnit.MINUTES);

        httpClient.addInterceptor(chain -> {
            Request original = chain.request();
            Request.Builder request = original.newBuilder();

            if (header.size() > 0) {
                for (Map.Entry<String, String> e : header.entrySet()) {
                    request.addHeader(e.getKey(), e.getValue());
                }
            }

            Utils.Log(ApiModule.class, "HEADER -----> " + new JSONObject(header).toString());
            request.method(original.method(), original.body());
            return chain.proceed(request.build());
        });

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        httpClient.addInterceptor(logging);

        OkHttpClient client = httpClient.build();
        Utils.Log(ApiModule.class, "URL -----> " + baseUrl);
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .client(client)
                .build();
    }

    /**
     * Gets retrofit object for gson api.
     *
     * @param baseUrl - base url as String for api server address
     * @param header  - header as hash map<String,String> for content type or token pass
     * @return - api interface and initialization retrofit object
     */
    public ApiInterface getRetrofitForGsonApi(String baseUrl, HashMap<String, String> header) {
        return GetRetrofitForGsonApi(baseUrl, header).create(ApiInterface.class);
    }
}
