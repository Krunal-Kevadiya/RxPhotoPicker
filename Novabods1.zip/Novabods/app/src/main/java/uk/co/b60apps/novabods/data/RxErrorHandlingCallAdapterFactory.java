package uk.co.b60apps.novabods.data;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import retrofit2.Call;
import retrofit2.CallAdapter;
import retrofit2.Retrofit;
import retrofit2.Response;
import rx.Observable;
import rx.functions.Func1;
import uk.co.b60apps.novabods.data.adapter.HttpException;
import uk.co.b60apps.novabods.data.adapter.RxJavaCallAdapterFactory;

public class RxErrorHandlingCallAdapterFactory extends CallAdapter.Factory {
    private final RxJavaCallAdapterFactory original;

    private RxErrorHandlingCallAdapterFactory() {
        original = RxJavaCallAdapterFactory.create();
    }

    public static CallAdapter.Factory create() {
        return new RxErrorHandlingCallAdapterFactory();
    }

    @Override
    public CallAdapter<?, ?> get(Type returnType, Annotation[] annotations, Retrofit retrofit) {
        return new RxJavaCallAdapter(retrofit, original.get(returnType, annotations, retrofit));
    }


    private static class RxJavaCallAdapter<R> implements CallAdapter<R, Object> {
        private Retrofit retrofit;
        private CallAdapter adapter;

        public RxJavaCallAdapter(Retrofit retrofit, CallAdapter callAdapter) {
            this.retrofit = retrofit;
            adapter = callAdapter;
        }


        @Override
        public Type responseType() {
            return adapter.responseType();
        }

        @Override
        @SuppressWarnings("unchecked")
        public Object adapt(Call<R> call) {
            return ((Observable) adapter.adapt(call)).onErrorResumeNext(new Func1<Throwable, Observable>() {
                @Override
                public Observable call(Throwable throwable) {
                    if (throwable instanceof HttpException) {
                        HttpException httpException = (HttpException) throwable;
                        final Response response = httpException.response();
                        String errorBody = "";
                        try {
                            errorBody = convertStreamToString(response.errorBody().byteStream());
                            return Observable.error(RetrofitException.unexpectedError(response.code(), errorBody, new RuntimeException(errorBody)));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        return Observable.error(RetrofitException.httpError(response.errorBody().toString(), response, "", retrofit));
                    }

                    // A network error happened
                    if (throwable instanceof IOException)
                        return Observable.error(RetrofitException.networkError(0, "", (IOException) throwable));

                    // We don't know what happened. We need to simply convert to an unknown error
                    return Observable.error(RetrofitException.unexpectedError(0, "", throwable));
                }
            });
        }

        private String convertStreamToString(InputStream is) throws IOException {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            is.close();
            return sb.toString();
        }
    }
}