package uk.co.b60apps.novabods.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*"user": {
    "user_id":2632, "user_account_id": 2342,
    "zuora_contact_id": null,
    "user_type_id":1,
    "email": "b60@educationcity.com",
    "firstname":"Andrew",
    "lastname":"Townsend",
    "display_name":null,
    "verification_token":null,
    "year_of_birth":null,
    "user_avatar_id":null,
    "credit":null
}*/

/**
 * The type User bean.
 */
public class UserBean {
    @SerializedName("user_id")
    @Expose
    private int userId;
    @SerializedName("user_account_id")
    @Expose
    private int userAccountId;
    @SerializedName("zuora_contact_id")
    @Expose
    private Object zuoraContactId;
    @SerializedName("user_type_id")
    @Expose
    private int userTypeId;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("firstname")
    @Expose
    private String firstname;
    @SerializedName("lastname")
    @Expose
    private String lastname;
    @SerializedName("display_name")
    @Expose
    private String displayName;
    @SerializedName("verification_token")
    @Expose
    private String verificationToken;
    @SerializedName("year_of_birth")
    @Expose
    private String yearOfBirth;
    @SerializedName("user_avatar_id")
    @Expose
    private int userAvatarId;
    @SerializedName("credit")
    @Expose
    private Object credit;

    /**
     * Gets user id.
     *
     * @return - user id as integer
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Sets user id.
     *
     * @param userId - user id as integer
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * Gets user account id.
     *
     * @return - user account id as integer
     */
    public int getUserAccountId() {
        return userAccountId;
    }

    /**
     * Sets user account id.
     *
     * @param userAccountId - user account id as integer
     */
    public void setUserAccountId(int userAccountId) {
        this.userAccountId = userAccountId;
    }

    /**
     * Gets zuora contact id.
     *
     * @return - zuora contact id as Object
     */
    public Object getZuoraContactId() {
        return zuoraContactId;
    }

    /**
     * Sets zuora contact id.
     *
     * @param zuoraContactId - zuora contact id as Object
     */
    public void setZuoraContactId(Object zuoraContactId) {
        this.zuoraContactId = zuoraContactId;
    }

    /**
     * Gets user type id.
     *
     * @return - user type id as integer
     */
    public int getUserTypeId() {
        return userTypeId;
    }

    /**
     * Sets user type id.
     *
     * @param userTypeId - user type id as integer
     */
    public void setUserTypeId(int userTypeId) {
        this.userTypeId = userTypeId;
    }

    /**
     * Gets user email.
     *
     * @return - email as String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets user email.
     *
     * @param email - email as String
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets user firstname.
     *
     * @return - firstname as String
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * Sets user firstname.
     *
     * @param firstname - firstname as String
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * Gets user lastname.
     *
     * @return - lastname as String
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * Sets user lastname.
     *
     * @param lastname - lastname as String
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * Gets display name.
     *
     * @return - display name as String
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets display name.
     *
     * @param displayName - display name as String
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Gets verification token.
     *
     * @return - verification token as String
     */
    public String getVerificationToken() {
        return verificationToken;
    }

    /**
     * Sets verification token.
     *
     * @param verificationToken - verification token as String
     */
    public void setVerificationToken(String verificationToken) {
        this.verificationToken = verificationToken;
    }

    /**
     * Gets year of birth.
     *
     * @return - year of birth as String
     */
    public String getYearOfBirth() {
        return yearOfBirth;
    }

    /**
     * Sets year of birth.
     *
     * @param yearOfBirth - year of birth as String
     */
    public void setYearOfBirth(String yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    /**
     * Gets user avatar id.
     *
     * @return - user avatar id as integer
     */
    public int getUserAvatarId() {
        return userAvatarId;
    }

    /**
     * Sets user avatar id.
     *
     * @param userAvatarId - user avatar id as integer
     */
    public void setUserAvatarId(int userAvatarId) {
        this.userAvatarId = userAvatarId;
    }

    /**
     * Gets credit.
     *
     * @return - credit as Object
     */
    public Object getCredit() {
        return credit;
    }

    /**
     * Sets credit.
     *
     * @param credit - credit as Object
     */
    public void setCredit(Object credit) {
        this.credit = credit;
    }

    @Override
    public String toString() {
        return "UserBean{" +
                "userId=" + userId +
                ", userAccountId=" + userAccountId +
                ", zuoraContactId=" + zuoraContactId +
                ", userTypeId=" + userTypeId +
                ", email='" + email + '\'' +
                ", firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                ", displayName=" + displayName +
                ", verificationToken=" + verificationToken +
                ", yearOfBirth=" + yearOfBirth +
                ", userAvatarId=" + userAvatarId +
                ", credit=" + credit +
                '}';
    }
}
