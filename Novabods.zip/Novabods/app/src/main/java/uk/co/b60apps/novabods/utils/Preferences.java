package uk.co.b60apps.novabods.utils;

import android.content.Context;
import android.content.SharedPreferences;
import uk.co.b60apps.novabods.R;

import static android.content.Context.MODE_PRIVATE;


/**
 * The type Preferences.
 */
public class Preferences {

    /**
     * Save current login user token.
     *
     * @param context - context as application context or activity context
     * @param token   - token as String
     */
    public static void saveToken(Context context, String token) {
        SharedPreferences preferences = context.getSharedPreferences(context.getString(R.string.pref_name), MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(context.getString(R.string.pref_token), token);
        editor.apply();
    }

    /**
     * Gets login user token.
     *
     * @param context - context as application context or activity context
     * @return - token as String
     */
    public static String getToken(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(context.getString(R.string.pref_name), MODE_PRIVATE);
        return preferences.getString(context.getString(R.string.pref_token), "");
    }

    /**
     * Clear login user token.
     *
     * @param context - context as application context or activity context
     */
    public static void clearToken(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(context.getString(R.string.pref_name), MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(context.getString(R.string.pref_token), "");
        editor.apply();
    }
}
