package uk.co.b60apps.novabods.viewmodels;

import com.kevadiyakrunalk.mvvmarchitecture.common.NavigatingViewModel;
import uk.co.b60apps.novabods.navigators.LoginNG;

public class LoginVM extends NavigatingViewModel<LoginNG> {
}
