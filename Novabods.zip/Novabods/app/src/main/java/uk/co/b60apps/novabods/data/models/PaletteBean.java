package uk.co.b60apps.novabods.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*{
    "palette_id": 1,
    "created": "2017-02-21 08:49:07",
    "modified": null,
    "name": "Red",
    "deselected_hex": "ff0000",
    "selected_hex": "cc0000",
    "nova_rover_wall_hex": "e83836",
    "deselected_rgb": {
        "R": 255,
        "G": 0,
        "B": 0
    },
    "selected_rgb": {
        "R": 204,
        "G": 0,
        "B": 0
    },
    "nova_rover_wall_rgb": {
        "R": 232,
        "G": 56,
        "B": 54
    }
}*/

/**
 * The type Palette bean.
 */
public class PaletteBean {
    @SerializedName("palette_id")
    @Expose
    private int paletteId;
    @SerializedName("created")
    @Expose
    private String created;
    @SerializedName("modified")
    @Expose
    private String modified;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("deselected_hex")
    @Expose
    private String deselectedHex;
    @SerializedName("selected_hex")
    @Expose
    private String selectedHex;
    @SerializedName("nova_rover_wall_hex")
    @Expose
    private String novaRoverWallHex;
    @SerializedName("deselected_rgb")
    @Expose
    private PaletteColor deselectedRgb;
    @SerializedName("selected_rgb")
    @Expose
    private PaletteColor selectedRgb;
    @SerializedName("nova_rover_wall_rgb")
    @Expose
    private PaletteColor novaRoverWallRgb;

    /**
     * Gets palette id.
     *
     * @return - palette id as integer
     */
    public int getPaletteId() {
        return paletteId;
    }

    /**
     * Sets palette id.
     *
     * @param paletteId - palette id as integer
     */
    public void setPaletteId(int paletteId) {
        this.paletteId = paletteId;
    }

    /**
     * Gets created.
     *
     * @return - created as String for palette created date
     */
    public String getCreated() {
        return created;
    }

    /**
     * Sets created date.
     *
     * @param created - created as String for palette created date
     */
    public void setCreated(String created) {
        this.created = created;
    }

    /**
     * Gets modified date.
     *
     * @return - modified as String for palette modified date
     */
    public String getModified() {
        return modified;
    }

    /**
     * Sets modified.
     *
     * @param modified - modified as String
     */
    public void setModified(String modified) {
        this.modified = modified;
    }

    /**
     * Gets palette name.
     *
     * @return - palette name as String
     */
    public String getName() {
        return name;
    }

    /**
     * Sets palette name.
     *
     * @param name - palette name as String
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets deselected hex.
     *
     * @return the deselected hex
     */
    public String getDeselectedHex() {
        return deselectedHex;
    }

    /**
     * Sets de-selected color hex code.
     *
     * @param deselectedHex - deselected color hex code as String
     */
    public void setDeselectedHex(String deselectedHex) {
        this.deselectedHex = deselectedHex;
    }

    /**
     * Gets selected color hex.
     *
     * @return - selected color hex as String
     */
    public String getSelectedHex() {
        return selectedHex;
    }

    /**
     * Sets selected color hex.
     *
     * @param selectedHex - selected color hex as String
     */
    public void setSelectedHex(String selectedHex) {
        this.selectedHex = selectedHex;
    }

    /**
     * Gets nova rover wall color hex.
     *
     * @return - nova rover wall color hex as String
     */
    public String getNovaRoverWallHex() {
        return novaRoverWallHex;
    }

    /**
     * Sets nova rover wall color hex.
     *
     * @param novaRoverWallHex - nova rover wall color hex as String
     */
    public void setNovaRoverWallHex(String novaRoverWallHex) {
        this.novaRoverWallHex = novaRoverWallHex;
    }

    /**
     * Gets de-selected color rgb.
     *
     * @return - deselected color rgb as PaletteColor
     */
    public PaletteColor getDeselectedRgb() {
        return deselectedRgb;
    }

    /**
     * Sets de-selected color rgb.
     *
     * @param deselectedRgb - deselected color rgb as paletteColor
     */
    public void setDeselectedRgb(PaletteColor deselectedRgb) {
        this.deselectedRgb = deselectedRgb;
    }

    /**
     * Gets selected color rgb.
     *
     * @return - selected color rgb as paletteColor
     */
    public PaletteColor getSelectedRgb() {
        return selectedRgb;
    }

    /**
     * Sets selected color rgb.
     *
     * @param selectedRgb - selected color rgb as paletteColor
     */
    public void setSelectedRgb(PaletteColor selectedRgb) {
        this.selectedRgb = selectedRgb;
    }

    /**
     * Gets nova rover wall color rgb.
     *
     * @return - nova rover wall color rgb as paletteColor
     */
    public PaletteColor getNovaRoverWallRgb() {
        return novaRoverWallRgb;
    }

    /**
     * Sets nova rover wall color rgb.
     *
     * @param novaRoverWallRgb - nova rover wall color rgb as paletteColor
     */
    public void setNovaRoverWallRgb(PaletteColor novaRoverWallRgb) {
        this.novaRoverWallRgb = novaRoverWallRgb;
    }

    @Override
    public String toString() {
        return "PaletteBean{" +
                "paletteId=" + paletteId +
                ", created='" + created + '\'' +
                ", modified=" + modified +
                ", name='" + name + '\'' +
                ", deselectedHex='" + deselectedHex + '\'' +
                ", selectedHex='" + selectedHex + '\'' +
                ", novaRoverWallHex='" + novaRoverWallHex + '\'' +
                ", deselectedRgb=" + deselectedRgb +
                ", selectedRgb=" + selectedRgb +
                ", novaRoverWallRgb=" + novaRoverWallRgb +
                '}';
    }
}