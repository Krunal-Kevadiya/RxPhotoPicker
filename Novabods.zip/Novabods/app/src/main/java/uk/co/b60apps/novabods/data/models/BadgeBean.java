package uk.co.b60apps.novabods.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*{
    "badge_id": 1,
    "created_at": "2017-02-21 08:49:06",
    "updated_at": null,
    "name": "world_1_location_1",
    "world_id": 1,
    "location_id": 1
}*/

/**
 * The type Badge bean.
 */
public class BadgeBean {
    @SerializedName("badge_id")
    @Expose
    private int badgeId;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("world_id")
    @Expose
    private int worldId;
    @SerializedName("location_id")
    @Expose
    private int locationId;

    /**
     * Gets badge id.
     *
     * @return - badge id as integer
     */
    public int getBadgeId() {
        return badgeId;
    }

    /**
     * Sets badge id.
     *
     * @param badgeId - badge id as integer
     */
    public void setBadgeId(int badgeId) {
        this.badgeId = badgeId;
    }

    /**
     * Gets created date of badge.
     *
     * @return - created at as String
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets created date of badge.
     *
     * @param createdAt - created at as String
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Gets updated date of badge.
     *
     * @return - updated at as String
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets updated date of badge.
     *
     * @param updatedAt - updated at as String
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Gets badge name.
     *
     * @return - name as String
     */
    public String getName() {
        return name;
    }

    /**
     * Sets badge name.
     *
     * @param name - name as String
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets badge world id.
     *
     * @return - world id as integer
     */
    public int getWorldId() {
        return worldId;
    }

    /**
     * Sets badge world id.
     *
     * @param worldId - world id as integer
     */
    public void setWorldId(int worldId) {
        this.worldId = worldId;
    }

    /**
     * Gets badge location id.
     *
     * @return - location id as integer
     */
    public int getLocationId() {
        return locationId;
    }

    /**
     * Sets badge location id.
     *
     * @param locationId - location id as integer
     */
    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    @Override
    public String toString() {
        return "BadgeBean{" +
                "badgeId=" + badgeId +
                ", createdAt='" + createdAt + '\'' +
                ", updatedAt=" + updatedAt +
                ", name='" + name + '\'' +
                ", worldId=" + worldId +
                ", locationId=" + locationId +
                '}';
    }
}