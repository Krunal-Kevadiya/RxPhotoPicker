package uk.co.b60apps.novabods.base;

import android.databinding.ViewDataBinding;

import com.kevadiyakrunalk.mvvmarchitecture.MvvmFragment;
import com.kevadiyakrunalk.mvvmarchitecture.common.MvvmViewModel;

/**
 * The type Base fragment.
 *
 * @param <S> - s as ViewDataBinding for data binding object and auto created by android
 * @param <U> - u as MvvmViewModel for presentation model to communicate XML and pojo class
 */
public abstract class BaseFragment<S extends ViewDataBinding, U extends MvvmViewModel> extends MvvmFragment<S, U> {
}
