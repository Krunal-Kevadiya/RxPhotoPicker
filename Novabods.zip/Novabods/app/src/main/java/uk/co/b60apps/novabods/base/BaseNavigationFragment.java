package uk.co.b60apps.novabods.base;

import android.databinding.ViewDataBinding;

import com.kevadiyakrunalk.mvvmarchitecture.NavigatingMvvmFragment;
import com.kevadiyakrunalk.mvvmarchitecture.common.NavigatingViewModel;
import com.kevadiyakrunalk.mvvmarchitecture.common.Navigator;

/**
 * The type Base fragment.
 *
 * @param <T> - t as Navigator for transaction between two activity/fragment or visa versa(Activity to Fragment, Fragment to Activity)
 * @param <S> - s as ViewDataBinding for data binding object and auto created by android
 * @param <U> - u as MvvmViewModel for presentation model to communicate XML and pojo class
 */
public abstract class BaseNavigationFragment<T extends Navigator, S extends ViewDataBinding, U extends NavigatingViewModel<T>> extends NavigatingMvvmFragment<T, S, U>{

    @Override
    public void onDestroy() {
        super.onDestroy();
        Runtime.getRuntime().gc();
    }
}
