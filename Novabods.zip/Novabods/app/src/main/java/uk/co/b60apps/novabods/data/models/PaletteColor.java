package uk.co.b60apps.novabods.data.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The type Palette color.
 */
public class PaletteColor {
    @SerializedName("R")
    @Expose
    private int r;
    @SerializedName("G")
    @Expose
    private int g;
    @SerializedName("B")
    @Expose
    private int b;

    /**
     * Gets red color shade.
     *
     * @return - r as integer
     */
    public int getR() {
        return r;
    }

    /**
     * Sets red color shade.
     *
     * @param r - r as integer
     */
    public void setR(int r) {
        this.r = r;
    }

    /**
     * Gets green color shade.
     *
     * @return - g as integer
     */
    public int getG() {
        return g;
    }

    /**
     * Sets green color shade.
     *
     * @param g - g as integer
     */
    public void setG(int g) {
        this.g = g;
    }

    /**
     * Gets blue color shade.
     *
     * @return - b as integer
     */
    public int getB() {
        return b;
    }

    /**
     * Sets blue color shade.
     *
     * @param b - b as integer
     */
    public void setB(int b) {
        this.b = b;
    }

    @Override
    public String toString() {
        return "PaletteColor{" +
                "r=" + r +
                ", g=" + g +
                ", b=" + b +
                '}';
    }
}