package uk.co.b60apps.novabods.data;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.Path;
import rx.Observable;
import uk.co.b60apps.novabods.data.models.UserBean;
import uk.co.b60apps.novabods.data.models.common.ErrorDetails;
import uk.co.b60apps.novabods.data.models.common.ResultBean;

/**
 * The interface Network service.
 */
public interface ApiInterface {
    /*// Member Protected Routes


    // OAuth Protected Routes

    @GET("account/{accountId}")
    Observable<ResultBean<Object>> getAccount(@Path("accountId") int accountId);

    @PATCH("account/{accountId}")
    Observable<ResultBean<Object>> editAccount(@Path("accountId") int accountId);

    @GET("account/{accountId}/user")
    Observable<ResultBean<Object>> getUserListFromAccount(@Path("accountId") int accountId, @Path("userId") int userId);

    @GET("account/{accountId}/user/{userId}")
    Observable<ResultBean<Object>> getUserFromAccount(@Path("accountId") int accountId, @Path("userId") int userId);

    @PATCH("account/{accountId}/user/{userId}")
    Observable<ResultBean<Object>> editUserFromAccount(@Path("accountId") int accountId, @Path("userId") int userId);

    @GET("account/{accountId}/user/{userId}/subscription")
    Observable<ResultBean<Object>> subscription(@Path("accountId") int accountId, @Path("userId") int userId);

    @POST("account/{accountId}/user/{userId}/error/{errorType}")
    Observable<ResultBean<Object>> error(@Path("accountId") int accountId, @Path("userId") int userId, @Path("errorType") String errorType);

    // Auth + Elevation Protected Routes

    @POST("elevate/user")
    Observable<ResultBean<Object>> newUserFromAccount();

    @PATCH("elevate/user")
    Observable<ResultBean<Object>> editUserFromAccount();

    @GET("elevate/user/unique/{email}")
    Observable<ResultBean<Object>> email(@Path("email") String email);

    @POST("elevate/account/{accountId}/user/{userId}/token")
    Observable<ResultBean<Object>> newToken(@Path("accountId") int accountId, @Path("userId") int userId);

    @PATCH("elevate/account/{accountId}/user/{userId}/token/{tokenId}")
    Observable<ResultBean<Object>> editToken(@Path("accountId") int accountId, @Path("userId") int userId, @Path("tokenId") String tokenId);

    @GET("elevate/account/{accountId}/user/{userId}/token")
    Observable<ResultBean<Object>> getToken(@Path("accountId") int accountId, @Path("userId") int userId);

    // Member/Trial Protected Routes

    @GET("navigation/user")
    Observable<ResultBean<Object>> getNavigationUserList();

    @GET("navigation/user/{userId}")
    Observable<ResultBean<Object>> getNavigationFromUser(@Path("userId") int userId);

    @GET("user/{userId}/score_token/content_location/{contentLocationId}")
    Observable<ResultBean<Object>> getContentLocationWaysToken(@Path("userId") int userId, @Path("contentLocationId") int contentLocationId);

    @GET("user/{userId}/world/{worldId}/location")
    Observable<ResultBean<Object>> getLocationList(@Path("userId") int userId, @Path("worldId") int worldId);

    @GET("user/{userId}/score/world/{worldId}")
    Observable<ResultBean<Object>> getWorldWaysScoreList(@Path("userId") int userId, @Path("worldId") int worldId);

    @GET("user/{userId}/score/content_location/{contentLocationId}")
    Observable<ResultBean<Object>> getScoreBasedOnUserAndContentLocation(@Path("userId") int userId, @Path("contentLocationId") int contentLocationId);

    @GET("world/{worldId}/location/{locationId}")
    Observable<ResultBean<Object>> getLocation(@Path("worldId") int worldId, @Path("locationId") int locationId);

    @GET("world/{worldId}/location/{locationId}/content")
    Observable<ResultBean<Object>> getContentList(@Path("worldId") int worldId, @Path("locationId") int locationId);

    @GET("world/{worldId}/location/{locationId}/content/{contentId}")
    Observable<ResultBean<Object>> getContent(@Path("worldId") int worldId, @Path("locationId") int locationId, @Path("contentId") int contentId);

    // OAuth + Elevation Routes

    @POST("authenticate/elevate")
    Observable<ResultBean<Object>> elevate();

    // Public Routes

    @POST("authenticate/login")
    Observable<ResultBean<UserBean>> login(@Body Map<String, String> options);

    @POST("authenticate/register")
    Observable<ResultBean<Object>> newRegister();

    @PATCH("authenticate/register")
    Observable<ResultBean<Object>> editRegister();

    @GET("authenticate/validate/{id}")
    Observable<ResultBean<Object>> getVerification(@Path("id") String id);

    @POST("authenticate/resend")
    Observable<ResultBean<Object>> resendVerification();

    @GET("authenticate/password/{passwordToken}")
    Observable<ResultBean<Object>> getPassword(@Path("passwordToken") String passwordToken);

    @POST("authenticate/password")
    Observable<ResultBean<Object>> newPassword();

    @PATCH("authenticate/password/{passwordToken}")
    Observable<ResultBean<Object>> editPassword(@Path("passwordToken") String passwordToken);

    @POST("user/{userId}/score/content_location/{contentLocationId}/score_token/{scoreToken}")
    Observable<ResultBean<Object>> saveScore(@Path("userId") int userId, @Path("contentLocationId") int contentLocationId, @Path("scoreToken") String scoreToken);

    @GET("token/{tokenId}")
    Observable<ResultBean<Object>> getToken(@Path("tokenId") String tokenId);

    @PATCH("token/{tokenId}/{type}")
    Observable<ResultBean<Object>> editToken(@Path("tokenId") String tokenId, @Path("type") String type);

    @GET("country")
    Observable<ResultBean<Object>> country();

    @GET("product/{currency}")
    Observable<ResultBean<Object>> product(@Path("currency") String currency);

    @GET("palette")
    Observable<ResultBean<Object>> palette();

    @GET("badge")
    Observable<ResultBean<Object>> badge();

    @GET("user/{userId}/score/content_location/{contentLocationId}/leaderboard")
    Observable<ResultBean<Object>> leaderboard(@Path("userId") int userId, @Path("contentLocationId") int contentLocationId);*/

    @POST("authenticate/login")
    Observable<ResultBean<UserBean, ErrorDetails>> login(@Body Map<String, String> options);

}
