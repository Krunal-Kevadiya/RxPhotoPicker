package uk.co.b60apps.novabods.utils;

import android.util.Log;

import uk.co.b60apps.novabods.BuildConfig;
import uk.co.b60apps.novabods.MyNovabods;

/**
 * The type Utils.
 */
public class Utils {
    /**
     * Print logcat in debug value.
     *
     * @param aClass - aclass as any class pass when you have define as a tag
     * @param msg    - msg as String
     */
    public static void Log(Class aClass, String msg) {
        if(BuildConfig.DEBUG) {
            if (aClass != null)
                Log.e(aClass.getSimpleName(), msg);
            else
                Log.e(MyNovabods.class.getSimpleName(), msg);
        }
    }
}
