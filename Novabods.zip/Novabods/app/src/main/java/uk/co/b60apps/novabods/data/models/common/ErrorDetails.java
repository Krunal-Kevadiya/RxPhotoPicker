package uk.co.b60apps.novabods.data.models.common;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ErrorDetails {
    @SerializedName("user_type_id")
    @Expose
    private List<String> userTypeId = null;
    @SerializedName("user_account_id")
    @Expose
    private List<String> userAccountId = null;
    @SerializedName("firstname")
    @Expose
    private List<String> firstname = null;
    @SerializedName("year_of_birth")
    @Expose
    private List<String> yearOfBirth = null;

    public List<String> getUserTypeId() {
        return userTypeId;
    }

    public void setUserTypeId(List<String> userTypeId) {
        this.userTypeId = userTypeId;
    }

    public List<String> getUserAccountId() {
        return userAccountId;
    }

    public void setUserAccountId(List<String> userAccountId) {
        this.userAccountId = userAccountId;
    }

    public List<String> getFirstname() {
        return firstname;
    }

    public void setFirstname(List<String> firstname) {
        this.firstname = firstname;
    }

    public List<String> getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(List<String> yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    @Override
    public String toString() {
        return "ErrorDetails{" +
                "userTypeId=" + userTypeId +
                ", userAccountId=" + userAccountId +
                ", firstname=" + firstname +
                ", yearOfBirth=" + yearOfBirth +
                '}';
    }
}